@extends('errors.custom-error')

@section('title', '500 Server Error')
@section('code', '500')
@section('message', 'Oops! Something went wrong on our end.')
