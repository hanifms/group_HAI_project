@extends('errors.custom-error')

@section('title', '404 Not Found')
@section('code', '404')
@section('message', 'Oops! The page you are looking for does not exist.')
